<?php
do_action( 'althos_footer_style' );

wp_footer();
?>
</body>
</html>